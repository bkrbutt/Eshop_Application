from django.contrib import admin
from django.urls import path
# from store.views import  
from .views.login import Login, logout
from .views.singup import Singup
from .views.index import Index
from .views.cart import Cart
from .views.checkout import CheckOut
from .views.orders import ordersView
from store.middlewares.auth import Auth_Middleware

urlpatterns = [
    path('', Index.as_view(), name='index'),
    path('singup', Singup.as_view(), name='singup'),
    path('singin', Login.as_view(), name='singin'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('check-out', CheckOut.as_view(), name='checkout'),
    path('orders', Auth_Middleware(ordersView.as_view()), name='orders'),
]