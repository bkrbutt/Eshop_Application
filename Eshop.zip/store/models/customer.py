from django.db import models
class Customer(models.Model):
    FirstName = models.CharField(max_length=25)
    LastName = models.CharField(max_length=25)
    Phone = models.CharField(max_length=25)
    Email= models.EmailField()
    password =models.CharField(max_length=500)

    def __str__(self):
        return self.FirstName

    def register(self):
        self.save()

    def get_customer_by_email(Email):
        try:
            return Customer.objects.get(Email= Email)
        except:
            return False

    def isExists(self):
        if Customer.objects.filter(Email=self.Email):
            return True
        
        return False
    
