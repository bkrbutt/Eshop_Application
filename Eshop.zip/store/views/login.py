from django.views import View
from django.shortcuts import render, redirect, HttpResponseRedirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
class Login(View):
   returnurl = None
   def get(self, request):
      Login.return_url=request.GET.get('return_url')
      return render(request, 'singin.html')
   
   def post(self, request):
      Email = request.POST.get('Email')
      password = request.POST.get('password')
      customer = Customer.get_customer_by_email(Email)
      error_message = None
      values = {'Email':Email}
      if customer:
        Flag = check_password(password, customer.password)
        if Flag:
          request.session['customer'] = customer.id
          if Login.return_url:
            return HttpResponseRedirect(Login.return_url)
          else:
            Login.return_url =None
            return redirect('index')
        else:
          error_message = "email or Password is incorrect"
      else:
        error_message = "email or Password is incorrect"
      return render(request, 'singin.html', {'error_message':error_message, 'values':values}) 
 
 
 
def logout(request):
  request.session.clear()
  return redirect('singin')