from django.views import View
from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from store.models import Product
from store.models.orders import Order
from store.middlewares.auth import Auth_Middleware
from django.utils.decorators import method_decorator




class ordersView(View):
    
    @method_decorator(Auth_Middleware)
    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        print(orders)
        orders = orders.reverse()
        return render(request, 'orders.html', {'orders':orders})