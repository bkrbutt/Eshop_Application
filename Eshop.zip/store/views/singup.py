
from django.views import View
from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password



class Singup(View):
   def get(self, request):
    return render(request, 'singup.html')
   
   def post(self, request):
      # <------Fetch form Data------>
        FirstName = request.POST.get('FirstName') 
        LastName = request.POST.get('LastName') 
        Phone = request.POST.get('Phone') 
        Email = request.POST.get('Email') 
        password = request.POST.get('password')
        values ={}
        values = {'FirstName':FirstName, 'LastName':LastName, 'Phone':Phone, 'Email':Email}
        # # <------Display Values at form------>
        customer = Customer(FirstName=FirstName, LastName=LastName,Phone=Phone, Email=Email, password=password)
        error_message= None
        if len(customer.password) < 9:
            error_message = 'Password Length should be more than 9 characters !!'
        elif not customer.FirstName:
            error_message = 'First Name can not be empty !!'
        elif not customer.LastName:
            error_message = 'Last Name can not be empty !!'
        elif not customer.Phone:
            error_message = 'Phone# can not be empty !!'
        # # <------Saving Form Data to db------>
        elif customer.isExists():
            error_message = ('Customer already available')
        # error_message = validateCustomer(customer)
        if error_message:
          print(error_message)
          return render(request, 'singup.html', {'values':values, 'error_message':error_message })
        if not error_message:
        # <----Hasing the Password----->
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('singin')
